package utils

import "strings"

func InStrok(argv string) string {
	return strings.TrimSpace(argv)
}
